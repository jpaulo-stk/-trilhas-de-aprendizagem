public class Main {
    public static void main(String[] args) {
        // Criando uma conta com saldo inicial
        Conta conta1 = new Conta("12345", "Joao Paulo", 500.00);

        // Exibindo informações da conta
        System.out.println(conta1);
        System.out.println();

        // Realizando um depósito
        conta1.depositar(300.00);
        System.out.println("Saldo atual: R$ " + conta1.getSaldo());
        System.out.println();

        // Tentando sacar um valor maior do que o saldo
        conta1.sacar(1000.00);
        System.out.println("Saldo atual: R$ " + conta1.getSaldo());
        System.out.println();

        // Realizando um saque válido
        conta1.sacar(200.00);
        System.out.println("Saldo atual: R$ " + conta1.getSaldo());
 }
}