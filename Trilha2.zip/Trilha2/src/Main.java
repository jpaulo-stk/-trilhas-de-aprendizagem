public class Main {
    public static void main(String[] args) {

        Universidade Princeton = new Universidade("Princeton (Nova Jersey - Estados Unidos da América)");
        Universidade Cambridge = new Universidade("Cambridge (Inglaterra)");

        Pessoa pessoa = new Pessoa("Albert Einstein", "14/3/1879", Princeton);
        Pessoa pessoa2 = new Pessoa("Isaac Newton", "4/1/1643", Cambridge);

        System.out.println(pessoa.getResultado());
        System.out.println(pessoa2.getResultado());
    }
}
