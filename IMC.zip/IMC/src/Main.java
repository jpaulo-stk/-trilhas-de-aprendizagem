public class Main {
    public static void main(String[] args) {
        // Criando alguns alunos
        Aluno aluno1 = new Aluno("Joao Paulo", 20, 90.5, 1.80);
        Aluno aluno2 = new Aluno("Thiago feio", 19, 95.0, 1.77);
        Aluno aluno3 = new Aluno("Vitor Giese", 24, 80.3, 1.80);
        Aluno aluno4 = new Aluno("Jhenyfer", 18, 50.2, 1.60);

        // Exibindo informações dos alunos
        System.out.println(aluno1);
        System.out.println();
        System.out.println(aluno2);
        System.out.println();
        System.out.println(aluno3);
        System.out.println();
        System.out.println(aluno4);
}
}